SELECT SUM(cases) AS TotalCases, SUM(deaths) AS TotalDeaths FROM CaseData;
